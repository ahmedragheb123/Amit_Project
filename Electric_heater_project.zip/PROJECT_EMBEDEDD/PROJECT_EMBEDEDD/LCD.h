/*
 * LCD.h
 *
 * Created: 1/31/2023 7:53:40 PM
 *  Author: DELL
 */ 


void command(char x);
void send(char y);