/*
 * timer.h
 *
 * Created: 1/31/2023 7:57:20 PM
 *  Author: DELL
 */ 
void Timer_int(void);
